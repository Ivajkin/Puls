	[       {"mark": "Chevrolet",	"model": ["1Model1", "1Model2", "1Model3"],      "img":  "http://upload.wikimedia.org/wikipedia/ru/thumb/3/34/Chevrolet_logo.png/200px-Chevrolet_logo.png"},
		{"mark": "Daewoo",	"model": ["2Model1", "2Model2", "2Model3"],      "img":  "http://img1.loadtr.com/b-303188-Daewoo_logo.jpg" },
		{"mark": "Honda",	"model": ["3Model1", "3Model2", "3Model3"],      "img":  "http://farm5.staticflickr.com/4064/4253120289_058ed34263_s.jpg" },
		{"mark": "Hyundai",	"model": ["4Model1", "4Model2"],     "img":  "http://www.cars-area.ru/pic/news/Hyundai_logo_1_small.jpg" },
                {"mark": "KIA",	"model": ["4Model1", "4Model2"],     "img":  "http://www.sewabah.com/logotype/KIA-LOGO1.gif" },
                {"mark": "SsangYong",	"model": ["4Model1", "4Model2"],     "img":  "http://www.avtologo.ru/img/ssangyong/ssangyong1_smal.jpg" },
	        {"mark": "Toyota",	"model": ["1Model1", "1Model2", "1Model3"],      "img":  "http://www.pickup-center.ru/img/pickups_logo/toyota_intro.jpg"},
		{"mark": "Mark2",	"model": ["2Model1", "2Model2", "2Model3"],      "img":  "test.png" },
		{"mark": "Mark3",	"model": ["3Model1", "3Model2", "3Model3"],      "img":  "test.png" },
		{"mark": "Mark4",	"model": ["4Model1", "4Model2"],     "img":  "test.png" },
                {"mark": "Mark4",	"model": ["4Model1", "4Model2"],     "img":  "test.png" }
	]