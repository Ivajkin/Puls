	[       {"type": "Легковая",	        "model": ["1Model1", "1Model2", "1Model3"]},
		{"type": "Внедорожник",	        "model": ["2Model1", "2Model2", "2Model3"]},
		{"type": "Малогрузная",	        "model": ["3Model1", "3Model2", "3Model3"]},
		{"type": "Большегрузная",	"model": ["4Model1", "4Model2"]},
                {"type": "Автобус",	        "model": ["4Model1", "4Model2"]},
                {"type": "Микроавтобус",	"model": ["4Model1", "4Model2"]},
	        {"type": "Сельхозтехника",	"model": ["1Model1", "1Model2", "1Model3"]},
		{"type": "Спецтехника",	        "model": ["2Model1", "2Model2", "2Model3"]}
	]