<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('Handling_Fee', '20');
define ('AUSPOST_TAX_CLASS', '0');
?>
