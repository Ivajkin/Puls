<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: intershipper.cfg.php 1095 2007-12-19 20:19:16Z soeren_nb $
* @package VirtueMart
* @subpackage shipping
* @copyright Copyright (C) 2004-2007 soeren - All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
define ('IS_USERNAME', 'xxxxxx');
define ('IS_PASSWORD', 'xxxxxxx');
define ('IS_EMAIL', 'yyyy@xxxx.com');
define ('IS_TAX_CLASS', '0');
define ('CARRIER1_NAME', 'UPS');
define ('CARRIER1_INVOICE', '0');
define ('CARRIER1_ACCOUNT', '');
define ('CARRIER2_NAME', 'FDX');
define ('CARRIER2_INVOICE', '0');
define ('CARRIER2_ACCOUNT', '');
define ('CARRIER3_NAME', 'DHL');
define ('CARRIER3_INVOICE', '0');
define ('CARRIER3_ACCOUNT', '');
define ('CARRIER4_NAME', '');
define ('CARRIER4_INVOICE', '0');
define ('CARRIER4_ACCOUNT', '');
define ('CARRIER5_NAME', '');
define ('CARRIER5_INVOICE', '0');
define ('CARRIER5_ACCOUNT', '');
define ('SERVICE_CLASS1', '1DY');
define ('SERVICE_CLASS2', '2DY');
define ('SERVICE_CLASS3', '3DY');
define ('SERVICE_CLASS4', '');
?>
