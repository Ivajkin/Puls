<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: ups.cfg.php 1095 2007-12-19 20:19:16Z soeren_nb $
* @package VirtueMart
* @subpackage shipping
* @copyright Copyright (C) 2004-2005 Soeren Eberhardt. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
define ('UPS_ACCESS_CODE', 'yyy');
define ('UPS_USER_ID', 'xxx-xxx');
define ('UPS_PASSWORD', 'yyyyyyyyyyyyyy');
define ('UPS_PICKUP_TYPE', '01');
define ('UPS_PACKAGE_TYPE', '02');
define ('UPS_RESIDENTIAL', 'yes');
define ('UPS_HANDLING_FEE', '0');
define ('UPS_TAX_CLASS', '0');
define ('UPS_TAX_BASIS', 'Shipping');
?>
