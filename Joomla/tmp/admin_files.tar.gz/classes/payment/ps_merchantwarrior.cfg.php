<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('MW_TEST_REQUEST', 'TRUE');
define ('MW_MERCHANT_UUID', '');
define ('MW_API_KEY', '');
define ('MW_VERIFIED_STATUS', 'C');
define ('MW_INVALID_STATUS', 'X');
?>