<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); ; 

define ('PaySbuy_EMAIL', 'you@yourbusiness.com');
define ('PaySbuy_CURRENCY', '840');
define ('PaySbuy_GATEWAY', '1');
define ('PaySbuy_LANG', '0');
?>